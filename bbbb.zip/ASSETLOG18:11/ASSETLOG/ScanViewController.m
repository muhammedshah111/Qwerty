//
//  scan.m
//  QBasset
//
//  Created by qbadmin on 11/4/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ScanViewController.h"
#import "SBJson.h"
@implementation scan
@synthesize signout;

@synthesize resultImage, resultText,ASSETID,labcategory,labcategorydata,labmodel,labmodeldata;

- (IBAction) scanButtonTapped
{
    // ADD: present a barcode reader that scans from the camera feed
    ZBarReaderViewController *reader = [ZBarReaderViewController new];
    reader.readerDelegate = self;
    reader.supportedOrientationsMask = ZBarOrientationMaskAll;
    
    ZBarImageScanner *scanner = reader.scanner;
    // TODO: (optional) additional reader configuration here
    
    // EXAMPLE: disable rarely used I2/5 to improve performance
    [scanner setSymbology: ZBAR_I25
                   config: ZBAR_CFG_ENABLE
                       to: 0];
    
    // present and release the controller
    [self presentModalViewController: reader
                            animated: YES];
    [reader release];
}

- (void) imagePickerController: (UIImagePickerController*) reader
 didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    // ADD: get the decode results
    id<NSFastEnumeration> results =
    [info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        // EXAMPLE: just grab the first barcode
        break;
    
    // EXAMPLE: do something useful with the barcode data
    ASSETID.hidden=FALSE;
    resultText.text = symbol.data;
    NSString *asset=resultText.text;
    NSString *post =[[NSString alloc] initWithFormat:@"asset=%@",asset];
    NSLog(@"%@",post);
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    
    
    NSURL *url = [NSURL URLWithString:@"http://10.3.0.132:8888/adminhome.php"]; // Modify this to match your url.
 	
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData]; 
    
    NSError *error;
    
    NSURLResponse *response;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...   
    
    SBJsonParser * jsonParser=[[SBJsonParser new]autorelease];
    
    NSDictionary *detailsOfCurrentAsset = [jsonParser objectWithString:responseData error:nil];
    
    
    NSString *resultcategory=[detailsOfCurrentAsset valueForKey:@"category"];
    NSString *resultmodel=[detailsOfCurrentAsset valueForKey:@"model"];
    //checking for successful login...
    //[dict objectForKey:@"email"];
    labcategory.hidden=FALSE;
    labcategorydata.hidden=FALSE;
    labmodel.hidden=FALSE;
    labmodeldata.hidden=FALSE;
   
    labcategorydata.text=resultcategory;
    labmodeldata.text=resultmodel;
    
    // EXAMPLE: do something useful with the barcode image
    resultImage.image =
    [info objectForKey: UIImagePickerControllerOriginalImage];
    
    // ADD: dismiss the controller (NB dismiss from the *reader*!)
    [reader dismissModalViewControllerAnimated: YES];
    if(labcategorydata.text.length==0)
    {
        labcategorydata.text=@"no data found";
    }
    if(labmodeldata.text.length==0)
    {
          labmodeldata.text=@"no data found";
    }
}

- (BOOL) shouldAutorotateToInterfaceOrientation: (UIInterfaceOrientation) orient
{
    return(YES);
}

- (void) dealloc {
    self.resultImage = nil;
    self.resultText = nil;
    [super dealloc];
}

- (IBAction)signout:(id)sender
{
    UINavigationController *navController;
    navController= (UINavigationController *)[self.storyboard instantiateViewControllerWithIdentifier:@"google"];
    
    [self presentModalViewController:navController animated:YES];
    
}
-(void) viewDidLoad
{
    ASSETID.hidden=true;
    labcategory.hidden=TRUE;
    labcategorydata.hidden=TRUE;
    labmodel.hidden=TRUE;
    labmodeldata.hidden=TRUE;
}

@end