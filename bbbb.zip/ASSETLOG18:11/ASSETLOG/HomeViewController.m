//
//  home.m
//  QBasset
//
//  Created by qbadmin on 11/4/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "HomeViewController.h"
#import "SBJson.h"
#import "OAuthSampleRootViewControllerTouch.h"


@implementation home
@synthesize labid;
@synthesize labemail;
@synthesize btncheckout;
@synthesize labiddata;
@synthesize checkin;
@synthesize labinuse;
@synthesize labinuseemail;
@synthesize signout;
-(IBAction)CheckoutAsset:(id)sender
{
    
    NSUserDefaults * use=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * emailid = [use valueForKey:@"emailid"];
    
    
    NSString *post =[[NSString alloc] initWithFormat:@"id=%@&email=%@",labiddata.text,emailid];
    NSLog(@"%@",post);
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    NSURL *url = [NSURL URLWithString:@"http://10.3.0.132:8888/checkout.php"]; // Modify this to match your url.
 	
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData];    
    NSError *error;
    
   NSURLResponse *response;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...   
    
   SBJsonParser * jsonParser=[[SBJsonParser new]autorelease];
    
    NSDictionary *detailsOfCurrentAsset = [jsonParser objectWithString:responseData error:nil];
    
    NSString *update=[detailsOfCurrentAsset valueForKey:@"update"];
     NSString *insert=[detailsOfCurrentAsset valueForKey:@"insert"];
   // NSLog(@"%@",result);
    if(([update isEqualToString:@"success"])&&([insert isEqualToString:@"success"]))
    {
        UIAlertView *Checkout = [[UIAlertView alloc] initWithTitle: @"Check in" message: @"The device is successfully checked in" delegate: self cancelButtonTitle: @"Ok" otherButtonTitles: nil];
        
        [Checkout show];
        [Checkout release];
        
        btncheckout.hidden = TRUE;
        checkin.hidden = FALSE;

      
    }
    else
    {
        UIAlertView *Checkout = [[UIAlertView alloc] initWithTitle: @"Check in" message: @"The device can not checked in" delegate: self cancelButtonTitle: @"Ok" otherButtonTitles: nil];
        
        [Checkout show];
        [Checkout release];
        
        btncheckout.hidden = FALSE;
        checkin.hidden = TRUE;  
    }
     
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewWillAppear:(BOOL)animated
{
[super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showLogin) name:@"logoutAction" object:nil];
    
    
    myTextField.hidden=TRUE;
    NSUserDefaults * user1=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * assetid1 = [user1 valueForKey:@"assetid"];
    
    if(assetid1.length==0)
    {
        
        UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"set asset id " message:@"this will set  asset id" delegate:self cancelButtonTitle:@"SET"  otherButtonTitles: nil];
        myTextField =[[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)];
        [myTextField setBackgroundColor:[UIColor whiteColor]];
        [myAlertView addSubview:myTextField];
        myAlertView.tag = 2;
        [myAlertView show];
        
        
        
    }
    //NSUserDefaults * user=[NSUserDefaults standardUserDefaults];
    
    // NSString * assetid = [user valueForKey:@"assetid"];
    NSUserDefaults * user=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * assetid = [user valueForKey:@"assetid"];
    
    labinuse.hidden=TRUE;
    labinuseemail.hidden=TRUE;
    
    
    
    
    NSUserDefaults * use=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * emailid = [use valueForKey:@"emailid"];
    
    
    labemail.text=emailid;
    
    
    NSString *post =[[NSString alloc] initWithFormat:@"email=%@&asset=%@",emailid,assetid];
    NSLog(@"%@",post);
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    NSURL *url = [NSURL URLWithString:@"http://10.3.0.132:8888/adminhome.php"]; // Modify this to match your url.
 	
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData]; 
    
    NSError *error;
    
    NSURLResponse *response;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...   
    
    SBJsonParser * jsonParser=[[SBJsonParser new]autorelease];
    
    NSDictionary *detailsOfCurrentAsset = [jsonParser objectWithString:responseData error:nil];
    
    NSString *resultid=[detailsOfCurrentAsset valueForKey:@"id"];
    
    NSString *resultstatus=[detailsOfCurrentAsset valueForKey:@"status"];
    NSString *heldby=[detailsOfCurrentAsset valueForKey:@"heldby"];
    //checking for successful login...
    //[dict objectForKey:@"email"];
    
    NSLog(@"%@",resultid);
    labiddata.text=resultid;
    
    
    if([resultstatus isEqualToString:@"available"]) 
    {
        btncheckout.hidden = FALSE;
        checkin.hidden = TRUE;
    }
    else if([resultstatus isEqualToString:@"unavailable"]) 
    { 
        if([heldby isEqualToString:@"same"]) 
        {
            btncheckout.hidden = TRUE;
            checkin.hidden = FALSE;
        } 
        else
        {   
            labinuse.hidden=FALSE;
            labinuseemail.hidden=FALSE;
            labinuseemail.text=heldby;
            btncheckout.hidden = TRUE;
            checkin.hidden = TRUE;
            
        } 
    }


}

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    
    
           
}
- (IBAction)checkin:(id)sender 
{
    
    
    
    NSString *post =[[NSString alloc] initWithFormat:@"id=%@",labiddata.text];
        
    NSURL *url=[NSURL URLWithString:@"http://10.3.0.132:8888/checkin.php"];
    
    
    //NSData *urlData=[self webService:post :url];
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData];   
    
    NSError *error;
    
    NSURLResponse *response;
    
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...    
    
    SBJsonParser * jsonParser=[SBJsonParser new];
    
    NSArray *detailsOfCurrentAsset= [jsonParser objectWithString:responseData error:nil];
    
    NSString * resultOfcheckinAction=[detailsOfCurrentAsset valueForKey:@"update"];
    
    if([resultOfcheckinAction isEqualToString:@"updated"])
        
    {     
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" 
                                                        message:@"device successfully checked out"
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles: nil];
        alert.tag=1;
        [alert show];
        
        checkin.hidden  = TRUE;
        btncheckout.hidden = FALSE;
        
        
    }
    
}  
    
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    
    
    
    
    
    if(alertView.tag == 2)
    {
    
        NSString *post =[[NSString alloc] initWithFormat:@"asset=%@",myTextField.text];
        NSLog(@"%@",post);
        
        NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
        
        NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
        
        NSURL *url = [NSURL URLWithString:@"http://10.3.0.132:8888/adminhome.php"]; // Modify this to match your url.
        
        NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
        
        [request setURL:url];
        
        [request setHTTPMethod:@"POST"];
        
        [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        [request setHTTPBody:postData]; 
        
        NSError *error;
        
        NSURLResponse *response;
        
        NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
        
        NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
        
        //getting response...   
        
        SBJsonParser * jsonParser=[[SBJsonParser new]autorelease];
        
        NSDictionary *detailsOfCurrentAsset = [jsonParser objectWithString:responseData error:nil];
        
        NSString *availableid=[detailsOfCurrentAsset valueForKey:@"idavailable"];
        if([availableid isEqualToString:@"yes"])
        {

            NSString *post1 =[[NSString alloc] initWithFormat:@"asset=%@",myTextField.text];
            NSLog(@"%@",post1);
            
            NSData *postData1 = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
            
            NSString *postLength1 = [NSString stringWithFormat:@"%d", [postData1 length]];
            
            NSURL *url1 = [NSURL URLWithString:@"http://10.3.0.132:8888/idcheck.php"]; // Modify this to match your url.
            
            NSMutableURLRequest *request1 = [[[NSMutableURLRequest alloc] init] autorelease];
            
            [request1 setURL:url1];
            
            [request1 setHTTPMethod:@"POST"];
            
            [request1 setValue:postLength1 forHTTPHeaderField:@"Content-Length"];
            [request1 setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            
            [request1 setHTTPBody:postData1]; 
            
            NSError *error1;
            
            NSURLResponse *response1;
            
            NSData *urlData1=[NSURLConnection sendSynchronousRequest:request1 returningResponse:&response1 error:&error1];
            
            NSString *responseData1=[[NSString alloc]initWithData:urlData1 encoding:NSUTF8StringEncoding];
            
            //getting response...   
            
            SBJsonParser * jsonParser1=[[SBJsonParser new]autorelease];
            
            NSDictionary *detailsOfCurrentAsset1 = [jsonParser1 objectWithString:responseData1 error:nil];
            
            NSString *available=[detailsOfCurrentAsset1 valueForKey:@"idavailable"];
            
            NSString *status=[detailsOfCurrentAsset1 valueForKey:@"status"];

         if([available isEqualToString:@"yes"])
         {
             if([status isEqualToString:@"notused"])  
             {
                 NSString *post2 =[[NSString alloc] initWithFormat:@"asset=%@",myTextField.text];
                 NSLog(@"%@",post2);
                 
                 NSData *postData2 = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
                 
                 NSString *postLength2 = [NSString stringWithFormat:@"%d", [postData2 length]];
                 
                 NSURL *url2 = [NSURL URLWithString:@"http://10.3.0.132:8888/idset.php"]; // Modify this to match your url.
                 
                 NSMutableURLRequest *request2 = [[[NSMutableURLRequest alloc] init] autorelease];
                 
                 [request2 setURL:url2];
                 
                 [request2 setHTTPMethod:@"POST"];
                 
                 [request2 setValue:postLength2 forHTTPHeaderField:@"Content-Length"];
                 [request2 setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
                 
                 [request2 setHTTPBody:postData2]; 
                 
                 NSError *error2;
                 
                 NSURLResponse *response2;
                 
                 NSData *urlData2=[NSURLConnection sendSynchronousRequest:request2 returningResponse:&response2 error:&error2];
                 
                 NSString *responseData2=[[NSString alloc]initWithData:urlData2 encoding:NSUTF8StringEncoding];
                 
                 //getting response...   
                 
                 SBJsonParser * jsonParser2=[[SBJsonParser new]autorelease];
                 
                 NSDictionary *detailsOfCurrentAsset2 = [jsonParser2 objectWithString:responseData2 error:nil];
                 
                 NSString *updated=[detailsOfCurrentAsset2 valueForKey:@"updated"];
                 
                if([updated isEqualToString:@"yes"]) 
                {
                 NSUserDefaults * userDeafaults=[NSUserDefaults standardUserDefaults];
                 [userDeafaults setValue:myTextField.text forKey:@"assetid"];   
                 [self viewWillAppear:TRUE];
                }
                 
             }
             else
             {
                 UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"used asset id " message:@"this will set the asset id" delegate:self cancelButtonTitle:@"SET"  otherButtonTitles: nil];
                 myTextField =[[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)];
                 [myTextField setBackgroundColor:[UIColor whiteColor]];
                 [myAlertView addSubview:myTextField];
                 myAlertView.tag = 2;
                 [myAlertView show]; 
             }
             
         }   
            
            
            
        }
        else
        {
            
            
            
            UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"invalid asset id " message:@"this will set the asset id" delegate:self cancelButtonTitle:@"SET"  otherButtonTitles: nil];
            myTextField =[[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)];
            [myTextField setBackgroundColor:[UIColor whiteColor]];
            [myAlertView addSubview:myTextField];
            myAlertView.tag = 2;
            [myAlertView show];
        }
    }
    


}
- (IBAction)signout:(id)sender
{
    UINavigationController *navController;
    navController= (UINavigationController *)[self.storyboard instantiateViewControllerWithIdentifier:@"google"];
    
    [self presentModalViewController:navController animated:YES];
    
}


- (void)viewDidUnload
{
    [myTextField release];
    myTextField = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [myTextField release];
    [super dealloc];
}
-(void) showLogin

{ 
    
    OAuthSampleRootViewControllerTouch *logout;
    logout=[[OAuthSampleRootViewControllerTouch alloc]init];
    [logout signOut];
    
    
    UIViewController *newViewController =
    
    [self.storyboard instantiateViewControllerWithIdentifier:@"google"];
    
    
    
    //[self.navigationController pushViewController:newViewController animated:YES];
    
    [self presentModalViewController:newViewController animated:NO];
    
    
    
}
@end
