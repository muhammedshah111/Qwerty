//
//  home.h
//  QBasset
//
//  Created by qbadmin on 11/4/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface home : UIViewController<UIAlertViewDelegate>
{
  
   
    IBOutlet UITextField *myTextField;
}
@property (nonatomic, retain) IBOutlet UILabel *labid;

@property (nonatomic, retain) IBOutlet UILabel *labemail;
@property (nonatomic, retain) IBOutlet UIButton *btncheckout;
- (IBAction)CheckoutAsset:(id)sender;
@property (nonatomic, retain) IBOutlet UILabel *labiddata; 
@property (nonatomic, retain) IBOutlet UILabel *labinuseemail;
@property (nonatomic, retain) IBOutlet UILabel *labinuse;
@property (nonatomic, retain) IBOutlet UIButton *checkin;
- (IBAction)checkin:(id)sender;
@property (nonatomic, retain) IBOutlet UIButton *signout;
- (IBAction)signout:(id)sender;
-(void) showLogin;
@end
