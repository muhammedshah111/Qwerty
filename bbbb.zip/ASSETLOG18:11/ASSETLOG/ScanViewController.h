//
//  scan.h
//  QBasset
//
//  Created by qbadmin on 11/4/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"

@interface scan :UIViewController<ZBarReaderDelegate >
{
    UIImageView *resultImage;
    UITextView *resultText;
}
@property (nonatomic, retain) IBOutlet UIImageView *resultImage;
@property (nonatomic, retain) IBOutlet UITextView *resultText;
- (IBAction) scanButtonTapped;
@property (nonatomic, retain) IBOutlet UIButton *signout;
- (IBAction)signout:(id)sender;
@property (nonatomic, retain) IBOutlet UILabel *ASSETID;
@property (nonatomic, retain) IBOutlet UILabel *labcategory;
@property (nonatomic, retain) IBOutlet UILabel *labcategorydata;
@property (nonatomic, retain) IBOutlet UILabel *labmodel;
@property (nonatomic, retain) IBOutlet UILabel *labmodeldata;
@end
