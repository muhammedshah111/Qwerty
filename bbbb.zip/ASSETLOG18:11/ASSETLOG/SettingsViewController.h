//
//  settings.h
//  QBasset
//
//  Created by qbadmin on 11/4/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface settings : UIViewController

@property (nonatomic, retain) IBOutlet UILabel *labid;
@property (nonatomic, retain) IBOutlet UILabel *labcategory;
@property (nonatomic, retain) IBOutlet UILabel *labmodel;
@property (nonatomic, retain) IBOutlet UIButton *btnedit;

@property (nonatomic, retain) IBOutlet UILabel *labiddata; 
@property (nonatomic, retain) IBOutlet UILabel *labcategorydata; 
@property (nonatomic, retain) IBOutlet UILabel *labmodeldata;
@property (nonatomic, retain) IBOutlet UIButton *signout;
- (IBAction)signout:(id)sender;


@end
