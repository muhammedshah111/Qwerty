//
//  edit.m
//  QBasset
//
//  Created by qbadmin on 11/4/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "EditViewController.h"
#import "SBJson.h"
#import "OAuthSampleRootViewControllerTouch.h"
@implementation edit
@synthesize labid;
@synthesize labcategory;
@synthesize labmodel;
@synthesize labiddata;
@synthesize btnupdate;
@synthesize txtmodel;
@synthesize txtcategory;
@synthesize signout;
@synthesize labcaterror;
@synthesize labmodelerror;
-(IBAction)txtpassReturn:(id)sender
{
    [sender resignFirstResponder];
} 
-(IBAction)backgroundTouched:(id)sender
{
    [txtmodel resignFirstResponder];
    [txtcategory resignFirstResponder];
}
- (IBAction)updateAsset:(id)sender
{
    if(txtcategory.text.length==0)
    {   labcaterror.hidden=FALSE;

        labcaterror.text=@"Enter a category";
                
    }
    else if(txtmodel.text.length==0)
    {   labmodelerror.hidden=FALSE;
        labmodelerror.text=@"Enter a model";
        
    }
    else     
    {
        
        
   
    
    NSString *post =[[NSString alloc] initWithFormat:@"id=%@&category=%@&model=%@",labiddata.text,txtcategory.text,txtmodel.text];
    NSLog(@"%@",post);
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    NSURL *url = [NSURL URLWithString:@"http://10.3.0.132:8888/update.php"]; // Modify this to match your url.
 	
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData];    
    NSError *error;
    
    NSURLResponse *response;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...   
    
    SBJsonParser * jsonParser=[[SBJsonParser new]autorelease];
    
    NSDictionary *detailsOfCurrentAsset = [jsonParser objectWithString:responseData error:nil];
    
    NSString *result=[detailsOfCurrentAsset valueForKey:@"updated"];
        NSString *validcategory=[detailsOfCurrentAsset valueForKey:@"validcategory"];
        NSString *validmodel=[detailsOfCurrentAsset valueForKey:@"validmodel"];
        
    NSLog(@"%@",result);
    
    
    if([result isEqualToString:@"success"])
    {
        UIAlertView *update = [[UIAlertView alloc] initWithTitle: @"Message" message: @"Asset details successfully updated" delegate: self cancelButtonTitle: @"Ok" otherButtonTitles: nil];
        
        [update show];
        [update release];
        UITabBarController *tabController;
        tabController= (UITabBarController *)[self.storyboard instantiateViewControllerWithIdentifier:@"admin"];
        [tabController setModalTransitionStyle:UIModalTransitionStyleFlipHorizontal];
        [self presentModalViewController:tabController animated:YES];    
    }
    else
    {
        UIAlertView *update = [[UIAlertView alloc] initWithTitle: @"Message" message: @"Asset details can not be updated" delegate: self cancelButtonTitle: @"Ok" otherButtonTitles: nil];
        
        [update show];
        [update release];
        if([validcategory isEqualToString:@"no"])
        {
            labcaterror.hidden=FALSE;
            
            labcaterror.text=@"Enter a valid category";
 
        }
        if([validmodel isEqualToString:@"no"])
        {
            labmodelerror.hidden=FALSE;
            labmodelerror.text=@"Enter a valid model";
        }
        
    }
    
           
    }
    
    

}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showLogin) name:@"logoutAction" object:nil];
    labcaterror.hidden=TRUE;
    labmodelerror.hidden=TRUE;
    NSUserDefaults * user=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * assetid = [user valueForKey:@"assetid"];
    NSString *post =[[NSString alloc] initWithFormat:@"asset=%@",assetid];
    NSLog(@"%@",post);
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];

    
    
    NSURL *url = [NSURL URLWithString:@"http://10.3.0.132:8888/adminhome.php"]; // Modify this to match your url.
 	
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
    
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
       [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData];   
  
    NSError *error;
    
    NSURLResponse *response;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...   
    
    SBJsonParser * jsonParser=[[SBJsonParser new]autorelease];
    
    NSDictionary *detailsOfCurrentAsset = [jsonParser objectWithString:responseData error:nil];
    
    NSString *resultid=[detailsOfCurrentAsset valueForKey:@"id"];
    NSString *resultcategory=[detailsOfCurrentAsset valueForKey:@"category"];
    NSString *resultmodel=[detailsOfCurrentAsset valueForKey:@"model"];
    //checking for successful login...
    //[dict objectForKey:@"email"];
    
    NSLog(@"%@",resultid);
    labiddata.text=resultid;
    txtcategory.text=resultcategory;
    txtmodel.text=resultmodel;
    
    
}


- (IBAction)signout:(id)sender
{
    UINavigationController *navController;
    navController= (UINavigationController *)[self.storyboard instantiateViewControllerWithIdentifier:@"google"];
    
    [self presentModalViewController:navController animated:YES];
    
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(void) showLogin

{ 
    
    OAuthSampleRootViewControllerTouch *logout;
    logout=[[OAuthSampleRootViewControllerTouch alloc]init];
    [logout signOut];
    
    
    UIViewController *newViewController =
    
    [self.storyboard instantiateViewControllerWithIdentifier:@"google"];
    
    
    
    //[self.navigationController pushViewController:newViewController animated:YES];
    
    [self presentModalViewController:newViewController animated:NO];
    
    
    
}

@end
