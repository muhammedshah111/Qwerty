//
//  Constants.h
//  ASSETLOG
//
//  Created by qbadmin on 11/23/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Constants : NSObject
#define ASSET_URL @"http://10.3.0.152:8888/adminhome.php"
#define UPDATE_URL @"http://10.3.0.152:8888/update.php"
#define CHECKOUT_URL @"http://10.3.0.152:8888/checkin.php"
#define CHECKIN_URL @"http://10.3.0.152:8888/checkout.php"
#define LOGIN_URL @"http://10.3.0.152:8888/adminhome.php"
#define CHECKID_URL @"http://10.3.0.152:8888/idcheck.php"
#define SETID_URL @"http://10.3.0.152:8888/idset.php"
#define CATEGORY_ERR_EMPTY @"Enter a category"
#define MODEL_ERR_EMPTY @"Enter a model"
#define CATEGORY_ERR_VALID @"Enter a valid category"
#define MODEL_ERR_VALID @"Enter a  valid model"
#define SUCCESS @"success"
#define NOT @"no"
#define POST @"POST"
#define CONTENT_LENGTH @"Content-Length"
#define SET_VALUE @"application/x-www-form-urlencoded"
#define CONTENT_TYPE @"Content-Type"
#define ID @"id"
#define CATEGORY @"category"
#define MODEL @"model"
@end
