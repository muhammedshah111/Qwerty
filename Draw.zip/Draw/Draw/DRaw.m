//
//  DRaw.m
//  Draw
//
//  Created by qbadmin on 1/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "DRaw.h"

@implementation DRaw
@synthesize array1=array1_,array2=array2_,wer=wer_;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
- (void)drawRect:(CGRect)rect {
    
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    float radius = 5.0f;
//    
//    CGContextBeginPath(context);
//	CGContextSetGrayFillColor(context, 0.8, 0.5);
//	CGContextMoveToPoint(context, CGRectGetMinX(rect) + radius, CGRectGetMinY(rect));
////    CGContextAddArc(context, CGRectGetMaxX(rect) - radius, CGRectGetMinY(rect) + radius, radius, 3 * M_PI / 2, 0, 0);
//    CGContextAddArc(context, CGRectGetMaxX(rect) - radius, CGRectGetMaxY(rect) - radius, radius, 0, M_PI / 2, 0);
//    CGContextAddArc(context, CGRectGetMinX(rect) + radius, CGRectGetMaxY(rect) - radius, radius, M_PI / 2, M_PI, 0);
//    CGContextAddArc(context, CGRectGetMinX(rect) + radius, CGRectGetMinY(rect) + radius, radius, M_PI, 3 * M_PI / 2, 0);
//	
//    CGContextClosePath(context);
//    CGContextFillPath(context);

   
    NSLog(@"%@",array1_);
      NSLog(@"%@",array2_);
    // Drawing code
    
    
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetLineWidth(context, 2.0);
    
//    CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
//    
//    CGFloat components[] = {0.0, 0.0, 1.0, 1.0};
//    
//    CGColorRef color = CGColorCreate(colorspace, components);
    CGContextSetStrokeColorWithColor(context, [UIColor blueColor].CGColor);
    
    CGContextMoveToPoint(context, 10, 5);
    CGContextAddLineToPoint(context, 10, 350);
    CGContextMoveToPoint(context, 10, 350);
    CGContextAddLineToPoint(context, 270, 350);
    CGContextStrokePath(context);

    
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
//    CGContextMoveToPoint(context, 10, 350);
//    CGContextAddLineToPoint(context, 30, 300);
    
    
    int z=[array1_ count];
    
    for (int n=0; n<z-1; n++) {
        
        int i=[[array1_ objectAtIndex:n] intValue];
        int j=[[array2_ objectAtIndex:n] intValue];
       
        NSLog(@"%d",i);
        NSLog(@"%d",j);
        
        int b=++n;
        
        int k=[[array1_ objectAtIndex:b] intValue];
        int r=[[array2_ objectAtIndex:b] intValue];
        NSLog(@"%d",k);
        NSLog(@"%d",r);
        CGContextMoveToPoint(context, i, j);
       
        CGContextAddLineToPoint(context, k, r);
        
        --n;
        
        CGContextStrokePath(context);

    }
    
    //    CGColorSpaceRelease(colorspace);
//    CGColorRelease(color);   
//    
  
   
    
    
}
//- (void)fillRoundedRect:(CGRect)rect inContext:(CGContextRef)context
//{
//    float radius = 5.0f;
//    
//    CGContextBeginPath(context);
//	CGContextSetGrayFillColor(context, 0.8, 0.5);
//	CGContextMoveToPoint(context, CGRectGetMinX(rect) + radius, CGRectGetMinY(rect));
//    CGContextAddArc(context, CGRectGetMaxX(rect) - radius, CGRectGetMinY(rect) + radius, radius, 3 * M_PI / 2, 0, 0);
//    CGContextAddArc(context, CGRectGetMaxX(rect) - radius, CGRectGetMaxY(rect) - radius, radius, 0, M_PI / 2, 0);
//    CGContextAddArc(context, CGRectGetMinX(rect) + radius, CGRectGetMaxY(rect) - radius, radius, M_PI / 2, M_PI, 0);
//    CGContextAddArc(context, CGRectGetMinX(rect) + radius, CGRectGetMinY(rect) + radius, radius, M_PI, 3 * M_PI / 2, 0);
//	
//    CGContextClosePath(context);
//    CGContextFillPath(context);
//}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
