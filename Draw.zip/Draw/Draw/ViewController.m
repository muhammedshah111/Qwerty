//
//  ViewController.m
//  Draw
//
//  Created by qbadmin on 1/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "DRaw.h"
@implementation ViewController
@synthesize xValue=xValue_;
@synthesize yValue=yValue_;
@synthesize sha;
@synthesize array1=array1_,array2=array2_;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
//    DRaw *gre=[[DRaw alloc]initWithFrame:CGRectMake(20, 10, 280, 400)] ;
//	// Do any additional setup after loading the view, typically from a nib.
//    [gre setBackgroundColor:[UIColor whiteColor]];
    
//    [self.view addSubview:gre];
      z=0;
     array1_=[[NSMutableArray alloc]init ];
      array2_=[[NSMutableArray alloc]init ];
    
    
}

- (void)viewDidUnload
{
    [xValue_ release];
    xValue_ = nil;
    [yValue_ release];
    yValue_ = nil;
    [self setXValue:nil];
    [self setYValue:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationLandscapeRight);
}

    - (void)dealloc {
        [sha release];
        [xValue_ release];
        [yValue_ release];
        [xValue_ release];
        [yValue_ release];
        [super dealloc];
    }
- (IBAction)GenerateGraph:(id)sender {
    
    
    NSLog(@"%@",array1_);
    NSLog(@"%@",array2_);
    
    
    
    DRaw *gre=[[DRaw alloc]initWithFrame:CGRectMake(20, 10, 280, 400)] ;
    
    
    gre.array1=array1_;
    gre.array2=array2_;
        
    [gre setBackgroundColor:[UIColor whiteColor]];
    
    [self.view addSubview:gre];
    
    
}

- (IBAction)NextValue:(id)sender {
    
    
    
    
   int i = [xValue_.text intValue];
    
    
   NSLog(@"%d",i);
    
    int j=[yValue_.text intValue];
    NSLog(@"%d",j);
    
   
    
  
    
    [array1_ addObject:[NSNumber numberWithInt:i]]; 
    
    [array2_ addObject:[NSNumber numberWithInt:j]]; 
    
    NSLog(@"%@",array1_);
    NSLog(@"%@",array2_);
    
    z++;
    
    xValue_.text=nil;
    yValue_.text=nil;
    
     
    
}
-(void) touchesBegan :(NSSet *) touches withEvent:(UIEvent *)event

{
    
    [xValue_ resignFirstResponder];
    
     [yValue_ resignFirstResponder];
    
    [super touchesBegan:touches withEvent:event ];
    
}   
+(void)shah{

//no code

}


   @end
