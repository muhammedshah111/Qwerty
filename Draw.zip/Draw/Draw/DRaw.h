//
//  DRaw.h
//  Draw
//
//  Created by qbadmin on 1/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol shah;

@interface DRaw : UIView
{
    id<shah> wer_;
    NSMutableArray *array1_;
    NSMutableArray *array2_;
}
@property (nonatomic,retain) NSMutableArray *array1;
@property (nonatomic,retain) NSMutableArray *array2;
@property (nonatomic,retain) id<shah> wer;
@end




@protocol shah <NSObject>

//methods

@end