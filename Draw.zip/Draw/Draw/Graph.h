//
//  Graph.h
//  Draw
//
//  Created by qbadmin on 1/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIView.h>
#import <UIKit/UITableView.h>
#import <UIKit/UIKitDefines.h>


@protocol graphDelegate;

@interface Graph : NSObject
//
ecfwcfewcf;
{
@private
    
    id<GraphDataDeligate> _dataSource;
    
    
}
@property(nonatomic,assign) id<GraphDataDeligate> dataSource; 

@end
ssdecsdcds
@protocol graphDelegate <NSObject>

- (NSInteger)numberOfComponentsInPickeView:(Graph *)graph;

// returns the # of rows in each component..
- (NSInteger)pickerView:(Graph *)graph; numberOfRowsInComponent:(NSInteger)component;


@end

//@end

//@protocol asdf <NSObject>
//
//@required
//
//
//- (NSInteger)numberOfComponentsInPickeView:(Graph *)graph;
//
//// returns the # of rows in each component..
//- (NSInteger)pickerView:(Graph *)graph; numberOfRowsInComponent:(NSInteger)component;
//
//@end
