//
//  ViewController.h
//  Draw
//
//  Created by qbadmin on 1/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
   
    IBOutlet UITextField *xValue_;
    
    IBOutlet UITextField *yValue_;
  
    int z;
    
    NSMutableArray * array1_;
    NSMutableArray * array2_;

}

@property (retain, nonatomic) IBOutlet UITextField *xValue;


@property (retain, nonatomic) IBOutlet UITextField *yValue;

@property (nonatomic,retain) NSMutableArray *array1;
@property (nonatomic,retain) NSMutableArray *array2;

@property (retain, nonatomic) IBOutlet UIView *sha;

+(void)shah;
- (IBAction)GenerateGraph:(id)sender;

- (IBAction)NextValue:(id)sender;


@end
