//
//  adsc.h
//  Draw
//
//  Created by qbadmin on 1/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol sdfg;

@interface adsc : NSObject
{

    id<sdfg> sdf_;


}
ewdewd
@property (nonatomic,retain) id<sdfg> sdf;

@end
 edcedc
@protocol sdfg <NSObject>

//metods

@end