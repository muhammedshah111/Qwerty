//
//  DrawTests.h
//  DrawTests
//
//  Created by qbadmin on 1/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface DrawTests : SenTestCase

@end
